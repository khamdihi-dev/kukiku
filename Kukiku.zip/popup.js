function updateCookies() {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      let currentTab = tabs[0];
      chrome.runtime.sendMessage(
        { action: "getCookies", url: currentTab.url },
        (response) => {
          if (response.cookies) {
            let cookieString = response.cookies.map(cookie => `${cookie.name}=${cookie.value}`).join("; ");
            document.getElementById("cookieList").textContent = cookieString;
          } else {
            document.getElementById("cookieList").textContent = "No cookies found.";
          }
        }
      );
    });
  }
  
  document.getElementById("getCookies").addEventListener("click", updateCookies);
  document.getElementById("copyCookies").addEventListener("click", () => {
    let cookieText = document.getElementById("cookieList").textContent;
    navigator.clipboard.writeText(cookieText).then(() => {
      alert("Cookies copied to clipboard!");
    }).catch(err => console.error("Error copying cookies:", err));
    updateCookies();
  });
  
  document.getElementById("subscribeBtn").addEventListener("click", updateCookies);
  document.getElementById("closePopup").addEventListener("click", () => {
    updateCookies();
    window.close();
  });
  
  document.addEventListener("DOMContentLoaded", updateCookies);
  